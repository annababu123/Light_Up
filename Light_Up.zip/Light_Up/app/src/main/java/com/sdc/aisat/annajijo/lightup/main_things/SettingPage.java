package com.sdc.aisat.annajijo.lightup.main_things;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.sdc.aisat.annajijo.lightup.R;

public class SettingPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_page);
    }
}
