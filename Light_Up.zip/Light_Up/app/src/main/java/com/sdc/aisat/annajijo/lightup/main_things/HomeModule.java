package com.sdc.aisat.annajijo.lightup.main_things;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.sdc.aisat.annajijo.lightup.R;
import com.sdc.aisat.annajijo.lightup.StaticClass;
import com.sdc.aisat.annajijo.lightup.my_class.PersonalRecord;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;




public class HomeModule extends AppCompatActivity {

    TextView name, email;
    Button donor_button,request_button,notification_button,blood_bank;

    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> arrayList;
    ListView listView;
    PersonalRecord personalRecord;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_module);

        name = (TextView) findViewById(R.id.nameIdd);
        email = (TextView) findViewById(R.id.emailIdd);
        donor_button = (Button) findViewById(R.id.donor_search);
        request_button = (Button) findViewById(R.id.request_button);
        notification_button = (Button) findViewById(R.id.notification_button);
        blood_bank = (Button) findViewById(R.id.blood_banks);



        FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                personalRecord = dataSnapshot.getValue(PersonalRecord.class);


                name.setText(personalRecord.getFirstName());

                email.setText(personalRecord.getEmail());

                StaticClass.personalRecord = personalRecord;
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        donor_button.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(new Intent(HomeModule.this, HomePage.class));
            }
        });

        request_button.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(new Intent(HomeModule.this, PostBloodRequirment.class));
            }
        });

        notification_button.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(new Intent(HomeModule.this, HomePage.class));
            }
        });
        blood_bank.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                startActivity(new Intent(HomeModule.this, SettingPage.class));
            }
        });

    }
}

