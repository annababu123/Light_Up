package com.sdc.aisat.annajijo.lightup;

import com.sdc.aisat.annajijo.lightup.my_class.PersonalRecord;

/**
 * Created by Farrukh Malik on 2/26/2017.
 */
public class StaticClass {

    public static PersonalRecord personalRecord;
}
